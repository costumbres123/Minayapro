package com.costumbrestintay.downloader

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.MediaStore
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.*
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val gold = 0xFFD6A84B.toInt()
    private val dark = 0xFF171923.toInt()
    private val panel = 0xFF252938.toInt()
    private val ivory = 0xFFF4EFE5.toInt()
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var server: ServerSocket? = null
    private lateinit var status: TextView
    private lateinit var filesText: TextView
    private var wifiRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 18)
            setBackgroundColor(dark)
        }
        val title = TextView(this).apply {
            text = "COSTUMBRES TINTAY"
            textSize = 21f; setTextColor(gold); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val sub = TextView(this).apply {
            text = "DOWNLOADER PRO  •  ANDROID"
            textSize = 11f; setTextColor(ivory); gravity = Gravity.CENTER
        }
        root.addView(title)
        root.addView(sub)
        root.addView(space(18))
        root.addView(label("BUSCADOR YOUTUBE"))
        val query = EditText(this).apply {
            hint = "Buscar en YouTube o pegar un enlace"
            setHintTextColor(0xFF9DA2B0.toInt()); setTextColor(ivory)
            setSingleLine(true); setPadding(14, 10, 14, 10)
            setBackgroundColor(panel)
        }
        root.addView(query, LinearLayout.LayoutParams(-1, 52))
        root.addView(button("BUSCAR / ABRIR EN YOUTUBE") {
            val q = query.text.toString().trim()
            if (q.isNotEmpty()) {
                val url = if (q.startsWith("http://") || q.startsWith("https://")) q
                          else "https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } else toast("Escribe una búsqueda o pega un enlace.")
        })
        root.addView(space(12))
        root.addView(label("BIBLIOTECA MULTIMEDIA"))
        root.addView(button("AÑADIR ARCHIVOS DEL TELÉFONO") { chooseFiles() })
        filesText = TextView(this).apply {
            text = "Los archivos importados se guardarán en Descargas/Costumbres Tintay para facilitar el acceso por USB."
            setTextColor(0xFFB7BAC4.toInt()); textSize = 12f; setPadding(4, 8, 4, 8)
        }
        root.addView(filesText)
        root.addView(space(8))
        root.addView(label("TRANSFERENCIA ENTRE MÓVIL Y PC"))
        root.addView(button("INICIAR / DETENER TRANSFERENCIA WI-FI") { toggleWifi() })
        status = TextView(this).apply {
            text = "Wi-Fi: detenido"
            setTextColor(gold); textSize = 13f; setPadding(4, 8, 4, 8)
        }
        root.addView(status)
        root.addView(button("COMPARTIR ARCHIVO POR USB / OTRAS APPS") { shareLatest() })
        root.addView(space(12))
        val note = TextView(this).apply {
            text = "Formatos: MP4 · MOV · MP3 · WAV · AAC\nLa app organiza archivos propios o autorizados. No extrae vídeos de YouTube. La búsqueda abre YouTube sin API Key."
            textSize = 11f; setTextColor(0xFF9297A5.toInt())
        }
        root.addView(note)
        root.addView(View(this).apply { setBackgroundColor(0xFF383C4A.toInt()) },
            LinearLayout.LayoutParams(-1, 1).apply { topMargin = 16; bottomMargin = 10 })
        root.addView(TextView(this).apply {
            text = "Revalorando nuestras vivencias culturales  •  costumbrestintay.com"
            textSize = 10f; setTextColor(gold); gravity = Gravity.CENTER
        })
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 11f; setTextColor(gold)
        setPadding(0, 4, 0, 8); setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun button(s: String, action: () -> Unit) = Button(this).apply {
        text = s; setTextColor(ivory); textSize = 12f
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF8C352D.toInt()))
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, 52).apply { topMargin = 7 }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun chooseFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, 100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 100 || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri) }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        var count = 0
        uris.forEach { uri -> try { copyToPublicDownloads(uri); count++ } catch (_: Exception) {} }
        filesText.text = "$count archivo(s) guardados en Descargas/Costumbres Tintay. Puedes copiarlos por USB desde el PC."
        toast("$count archivo(s) importados.")
    }

    private fun copyToPublicDownloads(uri: Uri) {
        val name = queryName(uri).replace("/", "_")
        val values = android.content.ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, contentResolver.getType(uri) ?: "application/octet-stream")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Costumbres Tintay")
        }
        val outUri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
        contentResolver.openInputStream(uri).use { input ->
            contentResolver.openOutputStream(outUri).use { output -> input?.copyTo(output!!) }
        }
    }

    private fun queryName(uri: Uri): String {
        var name = "media_${System.currentTimeMillis()}"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        return name
    }

    private fun toggleWifi() {
        if (wifiRunning) {
            try { server?.close() } catch (_: Exception) {}
            server = null; wifiRunning = false
            status.text = "Wi-Fi: detenido"
            return
        }
        executor.execute {
            try {
                val ss = ServerSocket(8765)
                server = ss; wifiRunning = true
                runOnUiThread {
                    status.text = "Servidor activo en puerto 8765.\nConsulta la IP Wi-Fi del móvil y abre http://IP:8765 en el PC."
                }
                while (!ss.isClosed) {
                    val socket = ss.accept()
                    executor.execute { handleClient(socket) }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Wi-Fi detenido: ${e.message ?: "sin conexión"}"; wifiRunning = false }
            }
        }
    }

    private fun handleClient(socket: Socket) {
        socket.use { s ->
            try {
                s.soTimeout = 15000
                val input = BufferedInputStream(s.getInputStream())
                val output = BufferedOutputStream(s.getOutputStream())
                val header = ByteArrayOutputStream()
                var state = 0
                while (state < 4) {
                    val b = input.read(); if (b == -1) return
                    header.write(b)
                    state = when {
                        state == 0 && b == 13 -> 1
                        state == 1 && b == 10 -> 2
                        state == 2 && b == 13 -> 3
                        state == 3 && b == 10 -> 4
                        b == 13 -> 1
                        else -> 0
                    }
                    if (header.size() > 16384) return
                }
                val raw = header.toString("ISO-8859-1")
                val lines = raw.split("\r\n")
                val parts = lines.first().split(" ")
                val method = parts.getOrNull(0) ?: "GET"
                val path = parts.getOrNull(1) ?: "/"
                val length = lines.firstOrNull { it.startsWith("Content-Length:", true) }
                    ?.substringAfter(":")?.trim()?.toLongOrNull() ?: 0L
                when {
                    method == "GET" && path.startsWith("/file/") -> {
                        val name = URLDecoder.decode(path.substringAfter("/file/"), "UTF-8")
                        val file = findPublicFile(name)
                        if (file == null) respond(output, 404, "No encontrado", "text/plain")
                        else {
                            val size = file.length()
                            output.write("HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: $size\r\nContent-Disposition: attachment; filename=\"$name\"\r\nConnection: close\r\n\r\n".toByteArray())
                            file.inputStream().use { it.copyTo(output) }; output.flush()
                        }
                    }
                    method == "POST" && path.startsWith("/upload/") -> {
                        val name = URLDecoder.decode(path.substringAfter("/upload/"), "UTF-8").replace("/", "_")
                        val target = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), name)
                        FileOutputStream(target).use { out ->
                            val buf = ByteArray(8192); var remaining = length
                            while (remaining > 0) {
                                val n = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                                if (n < 0) break
                                out.write(buf, 0, n); remaining -= n
                            }
                        }
                        respond(output, 200, "Archivo recibido: ${target.name}", "text/plain")
                    }
                    else -> {
                        val files = listPublicFiles()
                        val html = buildString {
                            append("<!doctype html><meta charset=utf-8><title>Costumbres Tintay</title>")
                            append("<body style='font:16px Arial;background:#171923;color:#f4efe5;padding:25px'>")
                            append("<h2 style='color:#d6a84b'>COSTUMBRES TINTAY · TRANSFERENCIA</h2>")
                            append("<p>Archivos del teléfono (Descargas/Costumbres Tintay)</p><ul>")
                            files.forEach { f -> append("<li><a style='color:#d6a84b' href='/file/${java.net.URLEncoder.encode(f.name,"UTF-8")}'>${f.name}</a> (${f.length()/1024} KB)</li>") }
                            append("</ul><h3>Enviar archivo del PC al móvil</h3>")
                            append("<form method=post enctype=application/octet-stream action='/upload/archivo.bin'><input type=file id=f><button type=button onclick='let x=document.getElementById(\"f\").files[0];let r=new XMLHttpRequest();r.open(\"POST\",\"/upload/\"+encodeURIComponent(x.name));r.upload.onprogress=e=>document.getElementById(\"p\").innerText=Math.round(e.loaded/e.total*100)+\"%\";r.onload=()=>alert(r.responseText);r.send(x)'>Subir archivo</button><span id=p></span></form>")
                            append("<p>Ambos dispositivos deben estar conectados a la misma red Wi-Fi.</p></body>")
                        }
                        respond(output, 200, html, "text/html; charset=utf-8")
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private fun respond(out: OutputStream, code: Int, body: String, type: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val reason = if (code == 200) "OK" else "Not Found"
        out.write("HTTP/1.1 $code $reason\r\nContent-Type: $type\r\nContent-Length: ${bytes.size}\r\nConnection: close\r\n\r\n".toByteArray())
        out.write(bytes); out.flush()
    }

    private fun listPublicFiles(): List<File> {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Costumbres Tintay")
        return dir.listFiles()?.filter { it.isFile } ?: emptyList()
    }
    private fun findPublicFile(name: String) = listPublicFiles().firstOrNull { it.name == name }

    private fun shareLatest() {
        val files = listPublicFiles()
        if (files.isEmpty()) { toast("Primero añade archivos a la biblioteca."); return }
        val f = files.last()
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.provider", f)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "*/*"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Compartir con DaVinci Resolve u otra aplicación"))
    }

    override fun onDestroy() {
        try { server?.close() } catch (_: Exception) {}
        executor.shutdownNow()
        super.onDestroy()
    }
}
