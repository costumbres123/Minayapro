# Costumbres Tintay Downloader PRO — Android

Proyecto Android Studio (Kotlin), versión inicial 0.1.0, orientado a Android 16.

## Incluye
- Búsqueda sin API Key: abre resultados de búsqueda de YouTube en la aplicación/navegador oficial.
- Importación de archivos multimedia locales mediante el selector del sistema.
- Copia a `Descargas/Costumbres Tintay` para acceso mediante USB/MTP.
- Servidor HTTP local para transferir archivos entre móvil y PC por Wi-Fi (puerto 8765).
- Interfaz corporativa grafito, oro andino y terracota.

## Construir APK
1. Instala Android Studio reciente con Android SDK Platform 36 y JDK 17.
2. Abre esta carpeta como proyecto.
3. Espera a que Gradle sincronice.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

## Transferencia USB
Los archivos importados se guardan en `Almacenamiento interno/Download/Costumbres Tintay`.
Conecta el móvil al PC, selecciona "Transferencia de archivos" y copia esa carpeta.

## Transferencia Wi-Fi
1. Conecta móvil y PC a la misma red Wi-Fi.
2. En la app pulsa "Iniciar transferencia Wi-Fi".
3. Averigua la IP local del móvil en Ajustes > Wi-Fi > red conectada.
4. En el navegador del PC abre `http://IP_DEL_MOVIL:8765`.
5. Descarga archivos listados o sube un archivo desde el PC.

El servidor Wi-Fi funciona mientras la app permanece abierta. Detén el servidor al terminar.
Esta primera implementación no incorpora autenticación ni cifrado TLS: úsala solo en una red privada de confianza y no en Wi-Fi público.

## Límites
- La app no descarga streams de YouTube. YouTube Data API no ofrece esa capacidad; la búsqueda abre YouTube sin clave.
- No convierte aún formatos ni importa directamente a DaVinci Resolve; organiza, comparte y transfiere medios locales.
- El botón de compartir utiliza el selector Android. La compatibilidad con DaVinci depende de las capacidades de la versión Android instalada.
- El servidor Wi-Fi es una base funcional para transferencias en red local; antes de distribuir públicamente debe añadirse autenticación, límites de tamaño y TLS.
